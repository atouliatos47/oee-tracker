// Main Application Logic
const oeeApp = {
    init() {
        // Wait for the DOM to be fully loaded
        document.addEventListener('DOMContentLoaded', () => {
            // Register service worker for PWA
            this.registerServiceWorker();

            // Initialize storage and load sample data if empty
            if (oeeStorage.getEntries().length === 0) {
                oeeStorage.initializeSampleData();
            }

            // Setup navigation
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', (e) => {
                    const pageId = e.target.getAttribute('data-page');
                    this.loadPage(pageId);
                });
            });

            // Initialize modules
            dataEntry.init();
            dashboard.loadDashboardData();
            dashboard.setupAutoRefresh();

            // Load the default dashboard page
            this.loadPage('dashboard');

            // Setup utility buttons
            this.setupUtilityButtons();
        });
    },

    registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/service-worker.js')
                .then(registration => {
                    console.log('Service Worker registered:', registration);
                })
                .catch(error => {
                    console.log('Service Worker registration failed:', error);
                });
        }
    },

    loadPage(pageId) {
        // Hide all pages
        const pages = document.querySelectorAll('.page');
        pages.forEach(page => {
            page.classList.remove('active');
        });

        // Show the target page
        const targetPage = document.getElementById(`${pageId}-page`);
        if (targetPage) {
            targetPage.classList.add('active');
        }

        // Update active nav link
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.classList.toggle('active', link.getAttribute('data-page') === pageId);
        });

        // Refresh dashboard if we are navigating to it
        if (pageId === 'dashboard') {
            dashboard.loadDashboardData();
        }
    },

    setupUtilityButtons() {
        // Export button
        const exportBtn = document.getElementById('export-data');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => dashboard.exportData());
        }

        // Clear data button
        const clearBtn = document.getElementById('clear-data');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => dashboard.clearAllData());
        }
    }
};

// Start the application
oeeApp.init();
