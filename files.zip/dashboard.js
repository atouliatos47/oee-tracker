// Dashboard Module - Handles all dashboard display logic
const dashboard = {
    init() {
        this.loadDashboardData();
    },

    loadDashboardData() {
        const entries = oeeStorage.getEntries();
        
        if (entries.length === 0) {
            this.showEmptyState();
            return;
        }

        this.updateStats(entries);
        this.renderTable(entries);
    },

    updateStats(entries) {
        const totalOEE = entries.reduce((sum, entry) => sum + (entry.oee || 0), 0);
        const avgOEE = totalOEE / entries.length;
        
        const totalAvailability = entries.reduce((sum, entry) => sum + (entry.availability || 0), 0);
        const avgAvailability = totalAvailability / entries.length;
        
        const totalPerformance = entries.reduce((sum, entry) => sum + (entry.performance || 0), 0);
        const avgPerformance = totalPerformance / entries.length;
        
        const totalQuality = entries.reduce((sum, entry) => sum + (entry.quality || 0), 0);
        const avgQuality = totalQuality / entries.length;

        // Update stat cards
        document.getElementById('overall-oee').textContent = avgOEE.toFixed(1) + '%';
        document.getElementById('overall-oee').style.color = this.getOEEColor(avgOEE);
        
        document.getElementById('avg-availability').textContent = avgAvailability.toFixed(1) + '%';
        document.getElementById('avg-availability').style.color = this.getOEEColor(avgAvailability);
        
        document.getElementById('avg-performance').textContent = avgPerformance.toFixed(1) + '%';
        document.getElementById('avg-performance').style.color = this.getOEEColor(avgPerformance);
        
        document.getElementById('avg-quality').textContent = avgQuality.toFixed(1) + '%';
        document.getElementById('avg-quality').style.color = this.getOEEColor(avgQuality);

        document.getElementById('total-entries').textContent = entries.length;
    },

    renderTable(entries) {
        const tbody = document.querySelector('#data-table tbody');
        tbody.innerHTML = '';

        // Sort by date (newest first)
        const sortedEntries = [...entries].sort((a, b) => 
            new Date(b.date) - new Date(a.date)
        );

        sortedEntries.forEach(entry => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${entry.date}</td>
                <td>${entry.area}</td>
                <td>${entry.shift}</td>
                <td style="color: ${this.getOEEColor(entry.availability)}">${entry.availability.toFixed(1)}%</td>
                <td style="color: ${this.getOEEColor(entry.performance)}">${entry.performance.toFixed(1)}%</td>
                <td style="color: ${this.getOEEColor(entry.quality)}">${entry.quality.toFixed(1)}%</td>
                <td style="color: ${this.getOEEColor(entry.oee)}; font-weight: 700;">${entry.oee.toFixed(1)}%</td>
            `;
            tbody.appendChild(row);
        });
    },

    getOEEColor(value) {
        if (value >= 85) return '#27ae60';  // Green
        if (value >= 70) return '#f39c12';  // Yellow/Orange
        return '#e74c3c';  // Red
    },

    showEmptyState() {
        const statsContainer = document.querySelector('.stats-grid');
        statsContainer.innerHTML = '<div class="empty-state">No data available. Add your first OEE entry!</div>';
        
        const tableBody = document.querySelector('#data-table tbody');
        tableBody.innerHTML = '<tr><td colspan="7" class="empty-state">No entries yet</td></tr>';
    },

    setupAutoRefresh() {
        // Refresh dashboard every 30 seconds
        setInterval(() => {
            const currentPage = document.querySelector('.page.active');
            if (currentPage && currentPage.id === 'dashboard-page') {
                this.loadDashboardData();
            }
        }, 30000);
    },

    exportData() {
        const csv = oeeStorage.exportToCSV();
        if (!csv) {
            alert('No data to export');
            return;
        }

        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `oee-data-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
    },

    clearAllData() {
        if (confirm('Are you sure you want to clear all OEE data? This cannot be undone.')) {
            oeeStorage.clearEntries();
            this.loadDashboardData();
            alert('All data has been cleared');
        }
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = dashboard;
}
