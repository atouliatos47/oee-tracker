// Storage Module - Handles all data persistence
const oeeStorage = {
    STORAGE_KEY: 'oee_data',

    // Get all entries from localStorage
    getEntries() {
        const data = localStorage.getItem(this.STORAGE_KEY);
        return data ? JSON.parse(data) : [];
    },

    // Save a new entry
    saveEntry(entry) {
        const entries = this.getEntries();
        entries.push(entry);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(entries));
    },

    // Clear all entries
    clearEntries() {
        localStorage.removeItem(this.STORAGE_KEY);
    },

    // Get entries for specific area
    getEntriesByArea(area) {
        return this.getEntries().filter(entry => entry.area === area);
    },

    // Get entries for specific date range
    getEntriesByDateRange(startDate, endDate) {
        const entries = this.getEntries();
        return entries.filter(entry => {
            const entryDate = new Date(entry.date);
            return entryDate >= startDate && entryDate <= endDate;
        });
    },

    // Calculate average OEE
    getAverageOEE() {
        const entries = this.getEntries();
        if (entries.length === 0) return 0;
        
        const sum = entries.reduce((acc, entry) => acc + (entry.oee || 0), 0);
        return sum / entries.length;
    },

    // Initialize with sample data
    initializeSampleData() {
        const sampleData = [
            {
                area: "Press 1",
                shift: "Day Shift",
                date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
                plannedProductionTime: 480,
                runtime: 420,
                totalParts: 950,
                goodParts: 920,
                idealCycleTime: 0.45,
                downtimeReason: "Setup",
                availability: 87.5,
                performance: 101.79,
                quality: 96.84,
                oee: 86.23
            },
            {
                area: "Press 2",
                shift: "Night Shift",
                date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
                plannedProductionTime: 480,
                runtime: 450,
                totalParts: 1020,
                goodParts: 1000,
                idealCycleTime: 0.42,
                downtimeReason: "None",
                availability: 93.75,
                performance: 100.67,
                quality: 98.04,
                oee: 92.51
            },
            {
                area: "Welding Line A",
                shift: "Day Shift",
                date: new Date().toISOString().split('T')[0],
                plannedProductionTime: 480,
                runtime: 410,
                totalParts: 870,
                goodParts: 850,
                idealCycleTime: 0.48,
                downtimeReason: "Material shortage",
                availability: 85.42,
                performance: 101.95,
                quality: 97.70,
                oee: 85.08
            }
        ];

        sampleData.forEach(entry => this.saveEntry(entry));
    },

    // Export data as CSV
    exportToCSV() {
        const entries = this.getEntries();
        if (entries.length === 0) return '';

        const headers = Object.keys(entries[0]);
        const csv = [
            headers.join(','),
            ...entries.map(entry => 
                headers.map(header => entry[header]).join(',')
            )
        ].join('\n');

        return csv;
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = oeeStorage;
}
