// Data Entry Module - Handles OEE data input and calculation
const dataEntry = {
    init() {
        this.renderForm();
        this.setupEventListeners();
    },

    renderForm() {
        const container = document.querySelector('.data-entry-form');
        container.innerHTML = `
            <div class="card">
                <h2>Enter OEE Data</h2>
                <form id="oee-entry-form">
                    <div class="form-group">
                        <label for="area">Production Area</label>
                        <select id="area" required>
                            <option value="">Select Area</option>
                            <option value="Press 1">Press 1</option>
                            <option value="Press 2">Press 2</option>
                            <option value="Press 3">Press 3</option>
                            <option value="Welding Line A">Welding Line A</option>
                            <option value="Welding Line B">Welding Line B</option>
                            <option value="Assembly 1">Assembly 1</option>
                            <option value="Paint Shop">Paint Shop</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="shift">Shift</label>
                        <select id="shift" required>
                            <option value="">Select Shift</option>
                            <option value="Day Shift">Day Shift (6:00 AM - 2:00 PM)</option>
                            <option value="Afternoon Shift">Afternoon Shift (2:00 PM - 10:00 PM)</option>
                            <option value="Night Shift">Night Shift (10:00 PM - 6:00 AM)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" id="date" required value="${new Date().toISOString().split('T')[0]}">
                    </div>

                    <div class="form-group">
                        <label for="plannedProductionTime">Planned Production Time (minutes)</label>
                        <input type="number" id="plannedProductionTime" required step="0.1" min="0" placeholder="e.g., 480">
                    </div>

                    <div class="form-group">
                        <label for="runtime">Actual Runtime (minutes)</label>
                        <input type="number" id="runtime" required step="0.1" min="0" placeholder="e.g., 420">
                    </div>

                    <div class="form-group">
                        <label for="totalParts">Total Parts Produced</label>
                        <input type="number" id="totalParts" required min="0" placeholder="e.g., 1000">
                    </div>

                    <div class="form-group">
                        <label for="goodParts">Good Parts (Quality)</label>
                        <input type="number" id="goodParts" required min="0" placeholder="e.g., 950">
                    </div>

                    <div class="form-group">
                        <label for="idealCycleTime">Ideal Cycle Time (minutes per part)</label>
                        <input type="number" id="idealCycleTime" required step="0.01" min="0" placeholder="e.g., 0.45">
                    </div>

                    <div class="form-group">
                        <label for="downtimeReason">Primary Downtime Reason (if any)</label>
                        <select id="downtimeReason">
                            <option value="None">None</option>
                            <option value="Setup">Setup/Changeover</option>
                            <option value="Breakdown">Equipment Breakdown</option>
                            <option value="Material shortage">Material Shortage</option>
                            <option value="Quality issue">Quality Issue</option>
                            <option value="Maintenance">Planned Maintenance</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="button-container">
                        <button type="button" class="btn btn-secondary" onclick="oeeApp.loadPage('dashboard')">
                            Back to Dashboard
                        </button>
                        <button type="submit" class="btn btn-success">
                            Save OEE Data
                        </button>
                    </div>
                </form>
            </div>

            <div id="calculation-result" class="card" style="display: none;">
                <h3>OEE Calculation Complete</h3>
                <div id="result-content"></div>
                <div style="margin-top: 1.5rem;">
                    <button class="btn" onclick="document.getElementById('calculation-result').style.display = 'none'; document.getElementById('oee-entry-form').reset(); document.getElementById('date').value = new Date().toISOString().split('T')[0];">
                        Add Another Entry
                    </button>
                </div>
            </div>
        `;
    },

    setupEventListeners() {
        document.querySelector('.data-entry-form').addEventListener('submit', (e) => {
            if (e.target.id === 'oee-entry-form') {
                e.preventDefault();
                this.handleFormSubmit();
            }
        });
    },

    handleFormSubmit() {
        const formData = this.getFormData();
        
        if (this.validateForm(formData)) {
            const oeeResult = this.calculateOEE(formData);
            this.saveEntry(formData, oeeResult);
            this.showResult(formData, oeeResult);
        }
    },

    getFormData() {
        return {
            area: document.getElementById('area').value,
            shift: document.getElementById('shift').value,
            date: document.getElementById('date').value,
            plannedProductionTime: parseFloat(document.getElementById('plannedProductionTime').value),
            runtime: parseFloat(document.getElementById('runtime').value),
            totalParts: parseInt(document.getElementById('totalParts').value),
            goodParts: parseInt(document.getElementById('goodParts').value),
            idealCycleTime: parseFloat(document.getElementById('idealCycleTime').value),
            downtimeReason: document.getElementById('downtimeReason').value
        };
    },

    validateForm(data) {
        if (data.goodParts > data.totalParts) {
            alert('Good parts cannot exceed total parts!');
            return false;
        }
        if (data.runtime > data.plannedProductionTime) {
            alert('Runtime cannot exceed planned production time!');
            return false;
        }
        if (!data.area || !data.shift || !data.date || isNaN(data.plannedProductionTime) || 
            isNaN(data.runtime) || isNaN(data.totalParts) || isNaN(data.goodParts) || 
            isNaN(data.idealCycleTime)) {
            alert('Please fill out all required fields with valid numbers.');
            return false;
        }
        if (data.plannedProductionTime <= 0 || data.runtime <= 0 || 
            data.totalParts <= 0 || data.idealCycleTime <= 0) {
            alert('Numeric values for time and parts must be greater than zero.');
            return false;
        }
        return true;
    },

    calculateOEE(data) {
        // Availability = Runtime / Planned Production Time
        const availability = (data.runtime / data.plannedProductionTime) * 100;
        
        // Performance = (Total Parts * Ideal Cycle Time) / Runtime
        const performance = ((data.totalParts * data.idealCycleTime) / data.runtime) * 100;
        
        // Quality = Good Parts / Total Parts
        const quality = (data.goodParts / data.totalParts) * 100;
        
        // Overall OEE = A * P * Q
        const oee = (availability / 100) * (performance / 100) * (quality / 100) * 100;
        
        return {
            availability: availability,
            performance: performance,
            quality: quality,
            oee: oee
        };
    },

    saveEntry(formData, oeeResult) {
        const entry = {
            ...formData,
            ...oeeResult
        };
        
        oeeStorage.saveEntry(entry);
        console.log('Entry saved:', entry);
        
        // Refresh dashboard data in the background
        dashboard.loadDashboardData();
    },

    showResult(formData, oeeResult) {
        const resultElement = document.getElementById('calculation-result');
        const contentElement = document.getElementById('result-content');
        
        contentElement.innerHTML = `
            <p><strong>Area:</strong> ${formData.area}</p>
            <p><strong>Shift:</strong> ${formData.shift}</p>
            <div class="result-grid">
                <div class="result-item">
                    <div class="result-value" style="color: ${dashboard.getOEEColor(oeeResult.availability)}">${oeeResult.availability.toFixed(1)}%</div>
                    <div class="result-label">Availability</div>
                </div>
                <div class="result-item">
                    <div class="result-value" style="color: ${dashboard.getOEEColor(oeeResult.performance)}">${oeeResult.performance.toFixed(1)}%</div>
                    <div class="result-label">Performance</div>
                </div>
                <div class="result-item">
                    <div class="result-value" style="color: ${dashboard.getOEEColor(oeeResult.quality)}">${oeeResult.quality.toFixed(1)}%</div>
                    <div class="result-label">Quality</div>
                </div>
                <div class="result-item" style="background: var(--primary); color: white;">
                    <div class="result-value" style="color: white">${oeeResult.oee.toFixed(1)}%</div>
                    <div class="result-label" style="color: var(--gray-light)">Overall OEE</div>
                </div>
            </div>
        `;
        
        resultElement.style.display = 'block';
        resultElement.scrollIntoView({ behavior: 'smooth' });
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = dataEntry;
}
